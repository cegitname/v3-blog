<template>
  <div class="container">
    <header class="navbar navbar-expand-lg sticky-top border-bottom">
      <nav class="container-xxl flex-lg-nowrap">
        <a class="navbar-brand" href="#">Navbar w/ text</a>
        <ul class="navbar-nav">
          <li class="nav-item" v-for="navItem in navList" :key="navItem.name">
            <a
              @click="linkTo(navItem)"
              class="nav-link"
              :class="{ active: navItem.name === 'H5' }"
              aria-current="page"
              href="#"
              >{{ navItem.name }}</a
            >
          </li>
        </ul>
      </nav>
    </header>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { useRouter, useRoute } from 'vue-router'
interface navItem {
  name: string
  path: string
}

export default defineComponent({
  name: 'mHeader',
  props: {
    msg: String
  },
  setup() {
    const router = useRouter()
    const route = useRoute()
    const linkTo = (navItem: navItem): void => {
      console.log(route, 'vvvvvvvvvvvv')
      router.push({ path: navItem.path })
    }
    const list = [
      { name: 'H5', path: '/h5' },
      { name: 'Read', path: '/read' }
    ]
    return {
      navList: list,
      linkTo
    }
  }
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
