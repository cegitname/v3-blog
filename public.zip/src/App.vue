<template>
  <m-header />
  <div class="container-xxl">
    <m-aside />
  </div>
  <router-view></router-view>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import mHeader from '@/layout/mHeader.vue'
import mAside from '@/layout/mAside.vue'

export default defineComponent({
  name: 'App',
  components: { mHeader, mAside }
})
</script>

<style lang="less"></style>
