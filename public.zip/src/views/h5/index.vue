<template>
  <div>h5</div>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  name: 'H5'
})
</script>
